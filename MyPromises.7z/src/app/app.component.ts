import { Component } from '@angular/core';
import { SearchService } from './base/services/search.service';

@Component({
  selector: "app-root",
  template: ` 
<form class="form-inline">
	<div class="form-group">
		<input type="search"
		       class="form-control"
		       placeholder="Enter search string"
		       #search>
	</div>
	<button type="button" class="btn btn-primary" (click)="doSearch(search.value)">Search</button>
</form>

<hr/>

<div class="text-center">
  <p class="lead" *ngIf="loading">Loading...</p>
</div>

<ul class="list-group">
	<li class="list-group-item"
	    *ngFor="let track of itunes.results">
		<img src="{{track.thumbnail}}">
		<a target="_blank"
		   href="{{track.link}}">{{ track.track }}
		</a>
	</li>
</ul>
 `
})
export class AppComponent {
  private loading: boolean = false;

  constructor(private itunes: SearchService) {}

  doSearch(term: string) {
    this.loading = true;
    this.itunes.search(term).then(_ => (this.loading = false));
  }
}
