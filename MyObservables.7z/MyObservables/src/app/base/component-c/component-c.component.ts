import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { MyIntercommunicationService } from 'src/app/services/my-intercommunication-api.service';

@Component({
  selector: 'component-c',
  templateUrl: './component-c.component.html',
  styleUrls: ['./component-c.component.scss']
})
export class ComponentCComponent implements OnDestroy {

  // Local Variables
  myLocalSubjectData: any;
  myLocalData: string;

  // Subscription to the observable
  mySubscription: Subscription;

  constructor(private _myIntercommunicationService: MyIntercommunicationService) {
    // On object instantiation, create a subscription to the observable
    this.mySubscription = this._myIntercommunicationService
      .getSubjectAsObservable()
      .subscribe(subjectData => {
        this.myLocalSubjectData = subjectData;
      }
      );
  }

  ngOnDestroy() {
    this.mySubscription.unsubscribe();
  }

  sendData(data:any) {
    this._myIntercommunicationService.sendSubjectData(this.myLocalData);
  }
}