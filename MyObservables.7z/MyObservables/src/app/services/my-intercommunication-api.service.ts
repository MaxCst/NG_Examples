import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MyIntercommunicationService {

  private mySubject = new Subject<any>();

  constructor() { }

  sendSubjectData(myData: any) {
    this.mySubject.next(myData);
  }

  clearSubjectData() {
    this.mySubject.next();
  }

  getSubjectAsObservable() {
    return this.mySubject.asObservable();
  }

}
