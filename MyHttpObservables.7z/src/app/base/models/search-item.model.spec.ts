import { SearchItem } from './search-item.model';

describe('SearchItem', () => {
  it('should create an instance', () => {
    expect(new SearchItem()).toBeTruthy();
  });
});
